alter table dbo.shipment_orders add is_edm bit null
alter table dbo.shipment_orders_log add is_edm bit null