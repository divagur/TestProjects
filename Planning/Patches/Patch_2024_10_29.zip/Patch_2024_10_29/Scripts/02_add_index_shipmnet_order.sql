CREATE INDEX shipment_order_shp_id_idx ON dbo.shipment_orders (shipment_id);
CREATE INDEX shp_ord_parts_shp_ord_id_idx ON dbo.shipment_order_parts (sh_order_id);